import { Img } from "./Img";
import { Text } from "./Text";
import { Heading } from "./Heading";
import { SelectBox } from "./SelectBox";
import { Input } from "./Input";
import { Button } from "./Button";
export { Img, Text, Heading, SelectBox, Input, Button };
