import React from "react";
import { Helmet } from "react-helmet";
import { Input, Img, Text, Button, Heading, SelectBox } from "../../components";
import Sidebar1 from "../../components/Sidebar1";

const dropDownOptions = [
  { label: "Option1", value: "option1" },
  { label: "Option2", value: "option2" },
  { label: "Option3", value: "option3" },
];

export default function InstagramMessagesPage() {
  return (
    <>
      <Helmet>
        <title>Instagram Direct Messages - Chat and Engage on Instagram</title>
        <meta
          name="description"
          content="Check your Instagram messages and engage with your followers. Send direct messages, share stories, and connect with The Boyz and friends."
        />
      </Helmet>

      {/* page container section */}
      <div className="flex w-full justify-center overflow-auto bg-white-A700 md:flex-col">
        {/* sidebar navigation section */}
        <Sidebar1 />

        {/* main content section */}
        <div className="flex flex-1 justify-center bg-gray-50 p-5 md:self-stretch">
          <div className="flex w-[81%] justify-evenly rounded border border-solid border-gray-300_01 md:w-full md:flex-col">
            {/* message list section */}
            <div className="w-[37%] border-r border-solid border-gray-300_01 bg-white-A700 md:w-full">
              {/* message list header section */}
              <div className="flex justify-between gap-5 border-b border-solid border-gray-300_01 bg-white-A700 pb-[18px] pl-[129px] pr-5 pt-[17px] md:pl-5">
                <SelectBox
                  shape="square"
                  indicator={<Img src="images/img_arrowdown.svg" alt="arrow_down" className="h-[20px] w-[20px]" />}
                  name="Dropdown Menu"
                  placeholder={`thegriff`}
                  options={dropDownOptions}
                  className="w-[42%] gap-px font-semibold text-black-900_01 sm:pr-5"
                />
                <Img src="images/img_edit.svg" alt="edit image" className="h-[24px] w-[24px]" />
              </div>
              <div className="bg-white-A700 pt-2">
                {/* message list items section */}
                <div className="flex flex-col gap-px pt-[72px] md:pt-5">
                  <div className="flex flex-1 bg-white-A700 p-2">
                    <div className="flex w-full items-center gap-3">
                      <Img
                        src="images/img_user_white_a700.png"
                        alt="user image"
                        className="h-[56px] w-[56px] object-cover"
                      />
                      <div className="flex flex-1 flex-col items-start">
                        <div className="flex items-start justify-between gap-5 self-stretch">
                          <Heading as="h1">The Boyz</Heading>
                          <div className="h-[8px] w-[8px] rounded bg-light_blue-A700" />
                        </div>
                        <Heading as="h2" className="relative mt-[-2px]">
                          <span className="text-black-900_01">joe68: sent a message&nbsp;</span>
                          <span className="font-normal text-black-900_01">·&nbsp;</span>
                          <span className="font-normal text-gray-600">34m</span>
                        </Heading>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-1 items-center gap-3 bg-white-A700 p-2">
                    <div className="w-[17%] rounded-[28px] border border-solid border-black-900_19 bg-gray-50">
                      <Img
                        src="images/img_image_2.png"
                        alt="profile image"
                        className="h-[56px] w-[56px] rounded-[50%]"
                      />
                    </div>
                    <div className="flex flex-1 flex-col items-start">
                      <Heading as="h3" className="relative z-[3]">
                        Lois Griffin
                      </Heading>
                      <div className="relative mt-[-3px] h-[8px] w-[8px] self-end rounded bg-light_blue-A700" />
                      <Heading as="h4" className="relative mt-[-2px]">
                        <span className="text-black-900_01">Sent you a message&nbsp;</span>
                        <span className="font-normal text-black-900_01">·&nbsp;</span>
                        <span className="font-normal text-gray-600">34m</span>
                      </Heading>
                    </div>
                  </div>
                  <div className="flex flex-1 items-center gap-3 bg-white-A700 p-2">
                    <div className="w-[17%] rounded-[28px] border border-solid border-black-900_19 bg-gray-50">
                      <Img src="images/img_image_6.png" alt="image" className="h-[56px] w-[56px] rounded-[50%]" />
                    </div>
                    <div className="flex flex-1 flex-col items-start">
                      <Heading as="h5" className="relative z-[4]">
                        Stewie Griffin
                      </Heading>
                      <div className="relative mt-[-3px] h-[8px] w-[8px] self-end rounded bg-light_blue-A700" />
                      <Heading as="h6" className="relative mt-[-2px]">
                        <span className="text-black-900_01">Sent you a message&nbsp;</span>
                        <span className="font-normal text-black-900_01">·&nbsp;</span>
                        <span className="font-normal text-gray-600">17h</span>
                      </Heading>
                    </div>
                  </div>
                  <div className="flex flex-1 items-center gap-3 bg-white-A700 p-2">
                    <div className="w-[17%] rounded-[28px] border border-solid border-black-900_19 bg-gray-50">
                      <Img src="images/img_image_3.png" alt="image" className="h-[56px] w-[56px] rounded-[50%]" />
                    </div>
                    <div className="flex flex-1 flex-col items-start">
                      <Heading as="p" className="relative z-[5]">
                        Joe Swanson
                      </Heading>
                      <div className="relative mt-[-3px] h-[8px] w-[8px] self-end rounded bg-light_blue-A700" />
                      <Heading as="p" className="relative mt-[-2px]">
                        <span className="text-black-900_01">Sent you a message&nbsp;</span>
                        <span className="font-normal text-black-900_01">·&nbsp;</span>
                        <span className="font-normal text-gray-600">20h</span>
                      </Heading>
                    </div>
                  </div>
                  <div className="flex flex-1 bg-white-A700 px-5 py-2">
                    <div className="flex w-[67%] items-center justify-between gap-5 md:w-full">
                      <div className="w-[29%] rounded-[28px] border border-solid border-black-900_19 bg-gray-50">
                        <Img src="images/img_image_7.png" alt="image" className="h-[56px] w-[56px] rounded-[50%]" />
                      </div>
                      <div className="flex flex-col items-start">
                        <Text as="p">Glenn Quagmire</Text>
                        <Text as="p" className="!text-gray-600">
                          <span className="text-gray-600">The silence lmao</span>
                          <span className="font-bold text-gray-600">&nbsp;</span>
                          <span className="text-black-900_01">·</span>
                          <span className="text-gray-600">&nbsp;20h</span>
                        </Text>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-1 bg-white-A700 px-5 py-2">
                    <div className="flex w-[51%] items-center justify-between gap-5 md:w-full">
                      <div className="w-[38%] rounded-[28px] border border-solid border-black-900_19 bg-gray-50">
                        <Img src="images/img_image_8.png" alt="image" className="h-[56px] w-[56px] rounded-[50%]" />
                      </div>
                      <div className="flex flex-col items-start gap-0.5">
                        <Text as="p">Herbert</Text>
                        <Text as="p" className="!text-gray-600">
                          Active 6m ago
                        </Text>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-1 bg-white-A700 px-5 py-2">
                    <div className="flex w-[47%] items-center justify-between gap-5 md:w-full">
                      <div className="w-[42%] rounded-[28px] border border-solid border-black-900_19 bg-gray-50">
                        <Img src="images/img_image_56x56.png" alt="image" className="h-[56px] w-[56px] rounded-[50%]" />
                      </div>
                      <div className="flex flex-col items-start gap-0.5">
                        <Text as="p">Adam West</Text>
                        <Text as="p" className="self-center !text-gray-600">
                          Active today
                        </Text>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-1 bg-gray-200 p-2">
                    <div className="flex w-full items-center justify-between gap-5">
                      <div className="w-[19%] rounded-[28px] border border-solid border-black-900_19 bg-gray-50">
                        <Img src="images/img_image_9.png" alt="image" className="h-[56px] w-[56px] rounded-[50%]" />
                      </div>
                      <div className="flex flex-col items-start">
                        <Text as="p">Philip J. Fry</Text>
                        <Text as="p" className="!text-gray-600">
                          <span className="text-gray-600">I feel like I was frozen for 1000...</span>
                          <span className="font-bold text-gray-600">&nbsp;</span>
                          <span className="text-black-900_01">·</span>
                          <span className="text-gray-600">&nbsp;20h</span>
                        </Text>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-1 bg-white-A700 px-5 py-2">
                    <div className="flex w-[56%] items-center justify-between gap-5 md:w-full">
                      <div className="w-[35%] rounded-[28px] border border-solid border-black-900_19 bg-gray-50">
                        <Img src="images/img_image_10.png" alt="image" className="h-[56px] w-[56px] rounded-[50%]" />
                      </div>
                      <div className="flex flex-col items-start gap-0.5">
                        <Text as="p">Cleveland Brown</Text>
                        <Text as="p" className="!text-gray-600">
                          Active 5h ago
                        </Text>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-1 bg-white-A700 px-5 py-2">
                    <div className="flex w-[47%] items-center justify-between gap-5 md:w-full">
                      <div className="w-[42%] rounded-[28px] border border-solid border-black-900_19 bg-gray-50">
                        <Img src="images/img_image_11.png" alt="image" className="h-[56px] w-[56px] rounded-[50%]" />
                      </div>
                      <div className="flex flex-col items-start gap-0.5">
                        <Text as="p">Chris Griffin</Text>
                        <Text as="p" className="self-center !text-gray-600">
                          Active today
                        </Text>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3 bg-white-A700 px-5 pt-2">
                  <div className="flex w-[19%] rounded-lg border border-solid border-black-900_19 bg-gray-50">
                    <Img
                      src="images/img_image_17x56.png"
                      alt="user image"
                      className="h-[17px] w-full rounded-lg object-cover"
                    />
                  </div>
                  <div className="flex self-end">
                    <Text as="p">Bonnie Swanson</Text>
                  </div>
                </div>
              </div>
            </div>

            {/* message thread section */}
            <div className="w-[62%] bg-white-A700 pb-5 md:w-full">
              {/* message thread header section */}
              <div className="flex flex-col items-center">
                <div className="flex items-center justify-between gap-5 self-stretch border-b border-solid border-gray-300_01 bg-white-A700 pb-2.5 pl-9 pr-5 pt-[9px] sm:pl-5">
                  <div className="flex w-[23%] items-center justify-center gap-3">
                    <Img
                      src="images/img_image_12.png"
                      alt="profile image"
                      className="h-[24px] w-[24px] rounded-[50%]"
                    />
                    <Heading size="lg" as="h6" className="self-end">
                      Philip J. Fry
                    </Heading>
                  </div>
                  <div className="flex gap-4 p-2">
                    <Img src="images/img_icon_7.svg" alt="ellipse icon" className="h-[24px] w-[24px]" />
                    <Img src="images/img_upload.svg" alt="upload icon" className="h-[24px] w-[24px]" />
                    <Img src="images/img_call.svg" alt="call icon" className="h-[24px] w-[24px]" />
                  </div>
                </div>

                {/* message thread conversation section */}
                <div className="flex flex-col items-end gap-2 self-stretch px-[7px] pb-[30px] pt-[9px] sm:pb-5">
                  <div className="flex w-[40%] flex-col items-end gap-2 md:w-full">
                    <div className="flex items-center gap-[15px] pl-[9px]">
                      <Text size="s" as="p" className="mb-2 self-end !text-gray-600">
                        You replied to their story
                      </Text>
                      <div className="h-full w-[4px] rounded-sm bg-gray-300_01" />
                    </div>
                    <Input
                      shape="round"
                      name="Input Field"
                      placeholder={`We’re at the Drunken Clam!`}
                      className="self-stretch !rounded-[22px] border-gray-200 sm:pr-5"
                    />
                  </div>
                  <div className="flex flex-col items-center self-stretch">
                    <div className="flex items-center gap-2 self-stretch">
                      <Img
                        src="images/img_image_12.png"
                        alt="profile image"
                        className="mb-4 h-[24px] w-[24px] self-end rounded-[50%]"
                      />
                      <div className="flex flex-col items-start">
                        <div className="flex self-center rounded-[22px] border border-solid border-gray-200 p-3.5">
                          <Text as="p">Be there in 10</Text>
                        </div>
                        <Button shape="circle" className="mt-[-14px] w-[30px] !rounded-[15px]">
                          <Img src="images/img_settings_light_blue_a700.svg" />
                        </Button>
                      </div>
                    </div>
                    <Text size="s" as="p" className="mt-[11px] !text-gray-600">
                      December 31, 2999 9:22 pm
                    </Text>
                    <div className="mt-[21px] flex w-[94%] flex-col items-end self-end md:w-full">
                      <div className="flex w-[46%] flex-col items-end gap-2 md:w-full">
                        <div className="flex items-center gap-[15px]">
                          <Text size="s" as="p" className="mb-2 self-end !text-gray-600">
                            You replied to their story
                          </Text>
                          <div className="h-full w-[4px] rounded-sm bg-gray-300_01" />
                        </div>
                        <div className="flex self-stretch rounded-[22px] border border-solid border-gray-200 bg-gray-200 px-3.5 pb-[13px] pt-3.5">
                          <Text as="p" className="w-[86%] leading-[18px]">
                            Man, you...uh.... you really disappeared on us.
                          </Text>
                        </div>
                      </div>
                      <Button shape="circle" className="mt-[-14px] w-[30px] !rounded-[15px]">
                        <Img src="images/img_settings_light_blue_a700.svg" />
                      </Button>
                    </div>
                    <div className="flex items-center gap-2 self-stretch pb-2">
                      <Img
                        src="images/img_image_12.png"
                        alt="profile image"
                        className="h-[24px] w-[24px] self-end rounded-[50%]"
                      />
                      <div className="flex w-[44%] justify-center rounded-[22px] border border-solid border-gray-200 px-3.5 pb-[13px] pt-3.5">
                        <Text as="p" className="w-[95%] leading-[18px]">
                          Shoot I’m sorry. I kind of cryogenically froze myself for 1000 years 😅
                        </Text>
                      </div>
                    </div>
                    <div className="flex w-[42%] justify-center self-end rounded-[22px] border border-solid border-gray-200 bg-gray-200 px-3.5 pb-[13px] pt-3.5 md:w-full">
                      <Text as="p" className="w-[94%] leading-[18px]">
                        You’re crazy man! I’ve wanted to do that for so long but Lois keeps saying no 🤬
                      </Text>
                    </div>
                    <Text size="s" as="p" className="mt-[19px] !text-gray-600">
                      January 1, 3000 9:04 am
                    </Text>
                    <div className="mt-[21px] flex items-center gap-2 self-stretch pb-2">
                      <Img
                        src="images/img_image_12.png"
                        alt="profile image"
                        className="h-[24px] w-[24px] self-end rounded-[50%]"
                      />
                      <div className="flex w-[44%] justify-center rounded-[22px] border border-solid border-gray-200 px-3.5 pb-[13px] pt-3.5">
                        <Text as="p" className="w-[95%] leading-[18px]">
                          OH GOD WHAT IS THIS PLACE. Aliens, robots oh no Peter I need your help!
                        </Text>
                      </div>
                    </div>
                  </div>
                </div>

                {/* message input area section */}
                <Input
                  size="md"
                  variant="outline"
                  shape="round"
                  color="undefined_undefined"
                  name="Emoji Input"
                  prefix={<Img src="images/img_emoji.svg" alt="emoji" className="h-[24px] w-[24px]" />}
                  suffix={
                    <Img
                      src="images/img_add_photo_or_video.svg"
                      alt="add photo or video"
                      className="h-[24px] w-[24px]"
                    />
                  }
                  className="w-[93%] gap-[35px] !rounded-[22px]"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
